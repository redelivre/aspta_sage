jQuery(document).ready(function() {
		// mantem o comportamento padrao desse tema
		// o div abaixo foi adicionado para uma funcionalidade do tema creta
		jQuery('div.delibera_opinioes_inferior').hide();
});
