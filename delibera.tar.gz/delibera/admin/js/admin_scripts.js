jQuery(document).ready(function()
{
	jQuery('.hasdatepicker:not([readonly])').datepicker({
		userLang	: 'pt-BR',
		americanMode: false,
	});
});

