<?php
// Adcionar as taxonomy a mais aqui.
